document.getElementById("login_form").addEventListener("submit", function(event) {
    event.preventDefault();

    var userN = document.getElementById("user_in").value.trim();
    var userPass = document.getElementById("pass_in").value.trim(); 

    // Checks the credentials in case username or password is empty
    if (userN === "") {
        alert("Please enter a valid username");
    } else if (userPass === "") {
        alert("Please enter a valid password");
    } else {
        if (userN === "admin" && userPass === "a") {
            console.log("Login successful"); 
            document.getElementById("log_box").style.display = "none"; // Hides the login UI if login is successful

            // Shows debit card info
            document.getElementById("debit-card").style.display = "block";

            var cardNumber = Math.floor(Math.random() * 10000) + " " + Math.floor(Math.random() * 10000) + " " + Math.floor(Math.random() * 10000) + " " + Math.floor(Math.random() * 10000);
            var expirationDate = (Math.floor(Math.random() * 12) + 1).toString().padStart(2, "0") + "/" + (Math.floor(Math.random() * 10) + 20);
            var cvv = Math.floor(Math.random() * 1000).toString().padStart(3, "0");

            // Updates the debit card info
            document.getElementById("debit-card-number").textContent = cardNumber;
            document.getElementById("debit-card-expiration").textContent = expirationDate;
            document.getElementById("debit-card-cvv").textContent = cvv;
        } else {
            alert("Incorrect username or password");
        }
    }
});

document.getElementById("deposit-btn").addEventListener("click", function() {
    var inputAmount = parseFloat(document.getElementById("input-deposit").value);
    var accountType = document.querySelector('input[name="account"]:checked').value;

    if (isNaN(inputAmount) || inputAmount <= 0) {
        alert("Please enter a valid deposit amount");
    } else {
        var balanceElement = document.getElementById(accountType + "-balance");
        var currentBalance = parseFloat(balanceElement.textContent);

        var totalDeposit = currentBalance + inputAmount;
        balanceElement.textContent = totalDeposit.toFixed(2);
        document.getElementById("deposit-number").textContent = inputAmount.toFixed(2);
        document.getElementById("input-deposit").value = ""; // Clear input field after deposit
        alert("Deposit of $" + inputAmount.toFixed(2) + " to " + accountType + " account completed.");
    }
});

document.getElementById("withdraw-btn").addEventListener("click", function() {
    var inputAmount = parseFloat(document.getElementById("input-withdraw").value);
    var accountType = document.querySelector('input[name="account"]:checked').value;
    var balanceElement = document.getElementById(accountType + "-balance");
    var currentBalance = parseFloat(balanceElement.textContent);

    if (isNaN(inputAmount) || inputAmount <= 0) {
        alert("Please enter a valid withdrawal amount");
    } else if (inputAmount > currentBalance) {
        alert("Insufficient funds");
    } else {
        var totalWithdrawal = currentBalance - inputAmount;
        balanceElement.textContent = totalWithdrawal.toFixed(2);
        document.getElementById("withdraw-number").textContent = inputAmount.toFixed(2);
        document.getElementById("input-withdraw").value = ""; // Clear input field after withdrawal
        alert("Withdrawal of $" + inputAmount.toFixed(2) + " from " + accountType + " account completed.");
    }
});

document.getElementById("transfer-btn").addEventListener("click", function() {
    var transferAmount = parseFloat(document.getElementById("input-transfer").value);
    var transferFrom = document.querySelector('input[name="transfer-from"]:checked').value;
    var transferTo = document.querySelector('input[name="transfer-to"]:checked').value;

    if (isNaN(transferAmount) || transferAmount <= 0) {
        alert("Please enter a valid transfer amount");
    } else {
        var fromBalanceElement = document.getElementById(transferFrom + "-balance");
        var toBalanceElement = document.getElementById(transferTo + "-balance");
        var fromBalance = parseFloat(fromBalanceElement.textContent);
        var toBalance = parseFloat(toBalanceElement.textContent);

        if (transferAmount > fromBalance) {
            alert("Insufficient funds in the transfer from account");
        } else {
            var newFromBalance = fromBalance - transferAmount;
            var newToBalance = toBalance + transferAmount;

            fromBalanceElement.textContent = newFromBalance.toFixed(2);
            toBalanceElement.textContent = newToBalance.toFixed(2);
            document.getElementById("input-transfer").value = ""; // Clear input field after transfer
            alert("Transfer of $" + transferAmount.toFixed(2) + " from " + transferFrom + " account to " + transferTo + " account completed.");
        }
    }
});
